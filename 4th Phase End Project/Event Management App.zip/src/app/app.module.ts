import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { ViewemployeeComponent } from './viewemployee/viewemployee.component';
import { UpdateemployeeComponent } from './updateemployee/updateemployee.component';
import { EventemployeesComponent } from './eventemployees/eventemployees.component';
import { LoginComponent } from './login/login.component';
import { NavbarpageComponent } from './navbarpage/navbarpage.component';

const routes:Routes=[
  {path:"",component:AppComponent},
  {path:"home",component:HomeComponent},
  {path:"eventemployees",component:EventemployeesComponent},
  {path:"addemployee",component:AddemployeeComponent},
  {path:"viewemployee/:id",component:ViewemployeeComponent},
  {path:"updateemployee/:id",component:UpdateemployeeComponent},
  {path:"loginpage",component:LoginComponent},
  {path:"navbar",component:NavbarpageComponent},
  ]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AddemployeeComponent,
    ViewemployeeComponent,
    UpdateemployeeComponent,
    EventemployeesComponent,
    LoginComponent,
    NavbarpageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
