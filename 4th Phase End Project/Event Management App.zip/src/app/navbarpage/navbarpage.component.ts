import { Component } from '@angular/core';

@Component({
  selector: 'app-navbarpage',
  templateUrl: './navbarpage.component.html',
  styleUrl: './navbarpage.component.css'
})
export class NavbarpageComponent {

}
