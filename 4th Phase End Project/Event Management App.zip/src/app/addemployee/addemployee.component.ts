import { Component, OnInit  } from '@angular/core';
import { EmployeeserviceService } from '../employeeservice.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrl: './addemployee.component.css'
})
export class AddemployeeComponent {

  employees: any[]=[];
  id=""
  first_name=""
  last_name=""
  email=""

  constructor(private employeeservice: EmployeeserviceService, private router: Router ) { }
 
  addemployee( first_name:string, last_name:string,  email:string ){
    
    first_name=first_name.trim();
    last_name=last_name.trim();
    email = email.trim();

    const employee={first_name,last_name, email};

    this.employeeservice.addemployee(employee).subscribe(newEmployee=>{
    this.employees.push(newEmployee);
    this.router.navigate(['/eventemployees']);

    })
  }

}
